T = int(input())
for tc in range(1,T+1):
    N = int(input())
    lst = list(map(int,input().split()))
    for _ in range(N):
        visited = [0] * 10
        for i in range(10):
            if i == 0 and lst[i] < 0 or i == 9 and lst[i] > 0:
                lst[i] *= -1
                if abs(lst[i])>=10:
                    lst[i], lst[i - 1] = lst[i] // 2, lst[i] // 2
                visited[i] = 1
            else:
                if visited[i] ==0:
                    if abs(lst[i]) >= 10:
                        lst[i + 1] += abs(lst[i] // 2)
                        lst[i - 1] += -abs(lst[i] // 2)
                        lst[i] = 0
                        visited[i+1] = 1
                        visited[i-1] = 1
                    else:
                        if lst[i]>0:
                            lst[i + 1] += lst[i]
                            visited[i+1] = 1
                        else:
                            lst[i - 1] += lst[i]
                            visited[i - 1] = 1
                        lst[i] = 0
            print(lst)